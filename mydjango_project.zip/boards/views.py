from django.http import HttpResponse
from django.shortcuts import render
from .models import User, Champions, Review, champion_skill_img_text, champion_tip
from django.contrib.auth.models import User
from .forms import ReviewForm

def index(request):
    board_list = champion_tip.objects.all()
    return render(request, 'boards/index.html', {'board_list': board_list})

def board_detail(request):
    champion = Champions.objects.all()
    return render(request, 'boards/detail.html', {'champion': champion})
